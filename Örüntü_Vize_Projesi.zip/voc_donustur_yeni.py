
import os
import json
import glob
import xml.etree.ElementTree as ET

input_folder = 'json'
output_folder = 'pascal_voc'
os.makedirs(output_folder, exist_ok=True)

def convert_labelme_to_voc(json_file, output_folder, class_name="trafik_levhasi"):
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    image_width = data.get('imageWidth')
    image_height = data.get('imageHeight')
    image_name = data.get('imagePath')

    if not image_width or not image_height:
        print(f"Skipping {json_file}: missing image dimensions.")
        return

    annotation = ET.Element("annotation")
    ET.SubElement(annotation, "folder").text = "VOC"
    ET.SubElement(annotation, "filename").text = image_name

    size = ET.SubElement(annotation, "size")
    ET.SubElement(size, "width").text = str(image_width)
    ET.SubElement(size, "height").text = str(image_height)
    ET.SubElement(size, "depth").text = "3"

    ET.SubElement(annotation, "segmented").text = "0"

    for shape in data["shapes"]:
        points = shape["points"]
        xs = [pt[0] for pt in points]
        ys = [pt[1] for pt in points]
        x_min = int(min(xs))
        y_min = int(min(ys))
        x_max = int(max(xs))
        y_max = int(max(ys))

        obj = ET.SubElement(annotation, "object")
        ET.SubElement(obj, "name").text = class_name
        ET.SubElement(obj, "pose").text = "Unspecified"
        ET.SubElement(obj, "truncated").text = "0"
        ET.SubElement(obj, "difficult").text = "0"

        bndbox = ET.SubElement(obj, "bndbox")
        ET.SubElement(bndbox, "xmin").text = str(x_min)
        ET.SubElement(bndbox, "ymin").text = str(y_min)
        ET.SubElement(bndbox, "xmax").text = str(x_max)
        ET.SubElement(bndbox, "ymax").text = str(y_max)

    xml_name = os.path.splitext(os.path.basename(json_file))[0] + ".xml"
    tree = ET.ElementTree(annotation)
    tree.write(os.path.join(output_folder, xml_name))

json_files = glob.glob(os.path.join(input_folder, '*.json')) + glob.glob(os.path.join(input_folder, '*.JSON'))

print("Toplam JSON dosyası:", len(json_files))
for json_path in json_files:
    print("İşleniyor:", json_path)
    convert_labelme_to_voc(json_path, output_folder)
