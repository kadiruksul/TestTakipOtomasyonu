
import json
import os
import glob

input_folder = 'json'
output_folder = 'yolo_labels'
os.makedirs(output_folder, exist_ok=True)

def convert_labelme_to_yolo(json_file, output_folder, class_id=0):
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    image_width = data.get('imageWidth')
    image_height = data.get('imageHeight')

    if not image_width or not image_height:
        print(f"Skipping {json_file}: missing image dimensions.")
        return

    yolo_lines = []
    for shape in data['shapes']:
        points = shape['points']
        xs = [pt[0] for pt in points]
        ys = [pt[1] for pt in points]
        x_min = min(xs)
        x_max = max(xs)
        y_min = min(ys)
        y_max = max(ys)

        x_center = ((x_min + x_max) / 2) / image_width
        y_center = ((y_min + y_max) / 2) / image_height
        width = (x_max - x_min) / image_width
        height = (y_max - y_min) / image_height

        line = f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}"
        yolo_lines.append(line)

    txt_filename = os.path.splitext(os.path.basename(json_file))[0] + '.txt'
    with open(os.path.join(output_folder, txt_filename), 'w') as out_file:
        out_file.write('\n'.join(yolo_lines))

json_files = glob.glob(os.path.join(input_folder, '*.json')) + glob.glob(os.path.join(input_folder, '*.JSON'))

print("Toplam JSON dosyası:", len(json_files))
for json_path in json_files:
    print("İşleniyor:", json_path)
    convert_labelme_to_yolo(json_path, output_folder)
